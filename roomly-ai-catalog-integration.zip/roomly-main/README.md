# Roomly

AI room-makeover studio: upload a room photo, pick a style and budget, and get a
structure-aware redesign with shoppable pieces.

## Stack

- **Frontend + API:** Next.js (App Router), React, Tailwind CSS
- **Database:** Supabase Postgres via Drizzle ORM (`makeovers`, `users` tables)
- **File storage:** Supabase Storage (private `room-photos` bucket, signed URLs)
- **AI generation:** Replicate image-to-image / ControlNet (optional; demo mode without it)

## Local development

```bash
npm install
cp .env.example .env.local   # fill in values
npm run dev
```

Without env vars the app runs in demo mode (no database, demo result image).

## Supabase setup (one time)

1. Create a free project at https://supabase.com (sign in with GitHub).
2. Project Settings -> Database -> copy the **Transaction pooler** connection
   string (port 6543) into `DATABASE_URL`.
3. Project Settings -> API -> copy the project URL, anon key and service-role
   key into the env vars. The service-role key is server-only; never expose it.
4. Push the schema:
   ```bash
   npx drizzle-kit push
   ```
5. Create a **private** storage bucket named `room-photos`
   (Dashboard -> Storage -> New bucket, public = off).
6. Lock the public Data API: run `supabase/rls.sql` in the SQL editor.
   This enables row level security with no public policies - browsers can
   never read the tables directly; only the server (service role) can.

## Security posture

- Database and storage are reachable **only** through the server API routes
  (service-role key stays server-side; the anon key alone can do nothing once
  `rls.sql` is applied).
- Room photos live in a private bucket and are exposed as signed URLs valid
  for 7 days.
- `GET /api/makeover/:id` uses the unguessable makeover UUID as the access
  token (capability URL). There is no user login yet; treat makeover links as
  private links. Supabase Auth + per-user ownership policies are the planned
  next step before public launch.

## Deploy (Vercel)

1. Push this repo to GitHub.
2. Import it at https://vercel.com/new (sign in with GitHub).
3. Add the same env vars in Project Settings -> Environment Variables.
4. Deploy. API routes run server-side; `REPLICATE_*` and the service-role key
   stay off the client.

## Environment variables

See `.env.example`. `REPLICATE_API_TOKEN` / `REPLICATE_MODEL` enable live AI
generation (paid per image on Replicate's side). Without them, the studio runs
in demo mode.

## API

- `POST /api/makeover` - create a makeover (persists to DB, uploads photo to
  Supabase Storage, starts a Replicate prediction when configured).
- `GET /api/makeover/:id` - poll makeover status; refreshes from Replicate.
- `GET /api/health` - configuration/reachability checks.


## Razorpay AI credit payments

This integration adds three illustrative one-time INR packs: Starter (3 credits / ₹49),
Popular (8 credits / ₹99), and Studio (20 credits / ₹199). These are starter defaults
and should be reviewed against your AI/provider costs, taxes, refunds and business model
before going live.

### One-time setup

1. In Supabase SQL Editor, run `supabase/razorpay-credit-system.sql`.
2. In Razorpay Dashboard, start in **Test Mode** and generate a Key ID and Key Secret.
3. In Vercel → Project → Settings → Environment Variables, add:
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`
   - `RAZORPAY_WEBHOOK_SECRET` (set after creating the webhook in step 4)
   - `DATABASE_URL` (Supabase Postgres transaction pooler)
   - `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` for signed-in account checkout
4. In Razorpay Dashboard → Webhooks, create a webhook URL:
   `https://YOUR-DOMAIN/api/payments/webhook`
   Set a long random webhook secret and subscribe to `payment.captured`,
   `order.paid`, and `payment.failed`. Copy the same webhook secret into Vercel.
5. Redeploy the Vercel project. The checkout button becomes available when the Razorpay
   key ID/secret are present and the database migration has run.
6. Set `ROOMLY_AI_CREDITS_REQUIRED=true` only when you want AI restyles to consume one
   credit each. Redeploy after changing the variable.

### Guest and account behavior

- Guest purchases are associated with a long random HttpOnly cookie; only its SHA-256
  hash is stored in Postgres. Do not clear the browser's Roomly guest cookie if you need
  to retain guest credits.
- Signed-in purchases are associated with the Supabase Auth user ID.
- When a guest later signs in, their remaining guest credits are transferred to that
  account by an atomic server-side operation.
- The balance endpoint never returns guest tokens or payment secrets.
- All payment, wallet, ledger and webhook tables have RLS enabled and no browser policies.

### Payment safety and test checklist

- The server chooses the pack price; it never trusts an amount from the browser.
- Checkout signatures are checked server-side against the order ID stored in Postgres.
- The server fetches the payment from Razorpay and only grants credits when it is captured.
- Webhook requests are validated against the raw-body HMAC signature; event IDs are
  deduplicated, and credit fulfillment runs in a database transaction.
- One credit is reserved before each full-room restyle or tap-to-add AI edit and refunded on known provider/budget errors.
  Review logs and test timeout/network failure scenarios before launch.
- Test successful, failed, cancelled and duplicate webhook flows using Test Mode first.
  Confirm `roomly_payment_orders`, `roomly_credit_wallets` and `roomly_credit_ledger`
  before switching to Live Mode.
- Test and Live API keys are different. Do not enable real payments until Razorpay account
  activation, test payments, privacy/terms, refund policy and support contact are ready.

### Endpoints

- `POST /api/payments/create-order` — create a server-priced Razorpay order.
- `POST /api/payments/verify` — verify checkout signature and captured payment status.
- `POST /api/payments/webhook` — verify Razorpay webhook signature and reconcile events.
- `GET /api/credits` — return current owner's credit balance.
- `POST /api/credits/claim` — transfer guest credits to a signed-in account.


## Roomly "Shop the look" catalog feature

The attached AI room-design guide recommends a hybrid pipeline: keep your own product catalog, use a vision model to choose catalog items for the room, render the room as a visualization, then show the real products and links underneath. This integration adds the catalog database/API and a consent-based "Shop the look" section after an AI restyle.

### Setup

1. In the Supabase dashboard for the project Roomly already uses, open **SQL Editor** and run `supabase/roomly-product-catalog.sql`.
2. Import real products using the header template `supabase/roomly-products-import-template.csv`. Start with a small, carefully checked set, then grow toward the guide's suggested 200–500 items. Do not import invented products or scrape retailer sites against their terms.
3. For each product, provide an accurate title, category, INR price, public HTTPS image URL, HTTPS product URL, brand, colour, style tags and room types. For Postgres array columns, use values such as `"{warm minimal,neutral,natural}"` for `style_tags` and `"{bedroom,living room}"` for `room_types`; encode `dimensions` as JSON such as `"{""width_cm"":80}"`. If the Supabase CSV importer cannot map arrays reliably, import via SQL or a small admin importer.
4. To enable photo-aware recommendations, create a Google Gemini API key in Google AI Studio and add it as the server-only environment variable `GEMINI_API_KEY` in your hosting provider. Do not use a `NEXT_PUBLIC_` prefix and never commit the key. Without this key, the feature uses style-tag and budget matching.
5. Deploy the updated project. After an AI restyle succeeds, visitors can optionally consent to sending their room photo to Gemini for recommendations. The photo is sent only when they tick the consent box and click the product-recommendation button.
6. Verify product images and links, prices, budget totals and privacy disclosures before promoting the feature publicly.

### Product accuracy and privacy

AI room images are visual concepts and may not show the exact catalog SKU. Product cards link to the actual catalog listing and are the source of truth. The recommendation endpoint only selects products that exist in the Roomly catalog and enforces the chosen budget on the server. If Gemini is not configured or fails, it falls back to matching the catalog's style tags and budget.

Roomly's app sends the image to the existing configured image-editing provider for restyling. The new catalog planner separately sends a room image to Google Gemini only after the user explicitly opts in on the "Shop the look" section. Update Roomly's privacy policy to accurately describe these providers and their terms before launch.

### Not included automatically

- No real retailer catalog is preloaded; add only real products and links you have permission to use.
- This is not a live Amazon catalog integration. Amazon affiliate/API access and terms must be handled separately.
- The initial implementation displays product cards below the render; it does not guarantee that the exact product SKU is visually composited into the generated room.
- The code package must still be built and tested in your hosting environment; no deployment is performed by this ZIP.
