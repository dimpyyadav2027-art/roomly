import { randomUUID } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/db";
import { getSessionUser } from "@/lib/auth";
import { getGuestToken, hashGuestToken } from "@/lib/razorpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const user = await getSessionUser(request);
  const token = getGuestToken(request);
  if (!user || !token) return NextResponse.json({ ok: true, transferred: 0 });
  const guestHash = hashGuestToken(token);
  const client = await getPool().connect();
  try {
    await client.query("begin");
    const guestResult = await client.query(
      `select id, balance from public.roomly_credit_wallets where guest_token_hash = $1 for update`,
      [guestHash],
    );
    const guest = guestResult.rows[0] as { id: string; balance: number } | undefined;
    const amount = Number(guest?.balance ?? 0);
    if (!guest || amount <= 0) {
      await client.query("commit");
      return NextResponse.json({ ok: true, transferred: 0 });
    }
    await client.query(
      `insert into public.roomly_credit_wallets (user_id, balance) values ($1, 0)
       on conflict (user_id) where user_id is not null do nothing`,
      [user.id],
    );
    const userWalletResult = await client.query(
      `select id from public.roomly_credit_wallets where user_id = $1 for update`,
      [user.id],
    );
    const userWallet = userWalletResult.rows[0] as { id: string } | undefined;
    if (!userWallet) throw new Error("Could not find account wallet");
    const transferId = randomUUID();
    await client.query(`update public.roomly_credit_wallets set balance = balance + $1, updated_at = now() where id = $2`, [amount, userWallet.id]);
    await client.query(`update public.roomly_credit_wallets set balance = 0, updated_at = now() where id = $1`, [guest.id]);
    await client.query(
      `insert into public.roomly_credit_ledger (wallet_id, kind, credits, transfer_id, note)
       values ($1, 'transfer_in', $2, $3, 'Guest credits claimed after sign-in'),
              ($4, 'transfer_out', $5, $3, 'Guest credits claimed after sign-in')`,
      [userWallet.id, amount, transferId, guest.id, -amount],
    );
    await client.query("commit");
    return NextResponse.json({ ok: true, transferred: amount });
  } catch (error) {
    await client.query("rollback").catch(() => {});
    console.error("Guest credit claim failed", error);
    return NextResponse.json({ error: "Could not transfer guest credits right now." }, { status: 503 });
  } finally {
    client.release();
  }
}
