import { NextRequest, NextResponse } from "next/server";
import { getOwnerWallet, getRazorpayConfig } from "@/lib/razorpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { owner, balance } = await getOwnerWallet(request);
    const tables = await (await import("@/db")).getPool().query(
      `select to_regclass('public.roomly_credit_wallets') as wallets,
              to_regclass('public.roomly_payment_orders') as orders`,
    );
    const ready = Boolean(tables.rows[0]?.wallets && tables.rows[0]?.orders);
    return NextResponse.json({
      enabled: getRazorpayConfig().enabled && ready,
      creditsRequired: process.env.ROOMLY_AI_CREDITS_REQUIRED === "true",
      balance,
      account: Boolean(owner.userId),
      packs: [
        { id: "starter", name: "Starter", credits: 3, price: "₹49" },
        { id: "popular", name: "Popular", credits: 8, price: "₹99", featured: true },
        { id: "studio", name: "Studio", credits: 20, price: "₹199" },
      ],
    });
  } catch (error) {
    console.error("Credit balance lookup failed", error);
    return NextResponse.json({ error: "Credits are temporarily unavailable." }, { status: 503 });
  }
}
