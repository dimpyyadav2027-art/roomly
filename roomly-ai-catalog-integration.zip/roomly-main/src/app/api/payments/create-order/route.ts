import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/db";
import {
  attachGuestCookie, CREDIT_PACKS, getRazorpayConfig, razorpayRequest,
  resolvePaymentOwner, type CreditPackId,
} from "@/lib/razorpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "Invalid request origin." }, { status: 403 });
  }
  const config = getRazorpayConfig();
  if (!config.enabled || !config.keyId) {
    return NextResponse.json({ error: "Payments are not configured yet." }, { status: 503 });
  }

  let body: { packId?: unknown };
  try { body = await request.json(); } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  const packId = body.packId;
  if (typeof packId !== "string" || !(packId in CREDIT_PACKS)) {
    return NextResponse.json({ error: "Choose a valid credit pack." }, { status: 400 });
  }
  const pack = CREDIT_PACKS[packId as CreditPackId];
  const { owner, newGuestToken } = await resolvePaymentOwner(request);

  let localId: string | undefined;
  try {
    const result = await getPool().query(
      `insert into public.roomly_payment_orders
        (user_id, guest_token_hash, pack_id, credits, amount_paise, currency, status)
       values ($1, $2, $3, $4, $5, 'INR', 'creating')
       returning id`,
      [owner.userId, owner.guestTokenHash, pack.id, pack.credits, pack.amountPaise],
    );
    localId = result.rows[0]?.id;
    if (!localId) throw new Error("Could not create local payment order");

    const order = await razorpayRequest<{ id: string; amount: number; currency: string }>(
      "/orders", "POST", {
        amount: pack.amountPaise,
        currency: "INR",
        receipt: `roomly_${String(localId).replace(/-/g, "").slice(0, 28)}`,
        notes: { roomly_order_id: localId, pack_id: pack.id, credits: String(pack.credits) },
      },
    );
    if (order.amount !== pack.amountPaise || order.currency !== "INR" || !order.id) {
      throw new Error("Payment provider returned an invalid order");
    }
    await getPool().query(
      `update public.roomly_payment_orders
          set razorpay_order_id = $1, status = 'created', updated_at = now()
        where id = $2`,
      [order.id, localId],
    );
    const response = NextResponse.json({
      orderId: order.id, amount: order.amount, currency: order.currency,
      keyId: config.keyId, pack: { id: pack.id, name: pack.name, credits: pack.credits, displayPrice: pack.displayPrice },
    });
    return attachGuestCookie(response, newGuestToken, new URL(request.url).protocol === "https:");
  } catch (error) {
    if (localId) {
      await getPool().query(
        `update public.roomly_payment_orders set status = 'failed', updated_at = now() where id = $1`,
        [localId],
      ).catch(() => {});
    }
    console.error("Could not create Razorpay order", error);
    const response = NextResponse.json({ error: "Could not start checkout. Please try again." }, { status: 502 });
    return attachGuestCookie(response, newGuestToken, new URL(request.url).protocol === "https:");
  }
}
