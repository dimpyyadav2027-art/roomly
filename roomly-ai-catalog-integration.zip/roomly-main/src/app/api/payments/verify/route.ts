import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/db";
import { getSessionUser } from "@/lib/auth";
import {
  getGuestToken, hashGuestToken, getRazorpayConfig, razorpayRequest,
  verifyHmacHex, fulfillCapturedPayment,
} from "@/lib/razorpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const { keySecret } = getRazorpayConfig();
  if (!keySecret) return NextResponse.json({ error: "Payments are not configured." }, { status: 503 });
  let body: { razorpay_order_id?: unknown; razorpay_payment_id?: unknown; razorpay_signature?: unknown };
  try { body = await request.json(); } catch {
    return NextResponse.json({ error: "Invalid payment response." }, { status: 400 });
  }
  const orderId = typeof body.razorpay_order_id === "string" ? body.razorpay_order_id : "";
  const paymentId = typeof body.razorpay_payment_id === "string" ? body.razorpay_payment_id : "";
  const signature = typeof body.razorpay_signature === "string" ? body.razorpay_signature : "";
  if (!/^order_[A-Za-z0-9]+$/.test(orderId) || !/^pay_[A-Za-z0-9]+$/.test(paymentId)) {
    return NextResponse.json({ error: "Invalid payment identifiers." }, { status: 400 });
  }

  const user = await getSessionUser(request);
  // Keep guest ownership available during a sign-in transition, so an order
  // started before sign-in can still be verified using the HttpOnly guest cookie.
  const guestToken = getGuestToken(request);
  const guestHash = guestToken ? hashGuestToken(guestToken) : null;
  const orderResult = await getPool().query(
    `select id, user_id, guest_token_hash, amount_paise, currency, status
       from public.roomly_payment_orders
      where razorpay_order_id = $1
        and (($2::uuid is not null and user_id = $2::uuid)
          or ($3::text is not null and guest_token_hash = $3::text))
      limit 1`,
    [orderId, user?.id ?? null, guestHash],
  );
  const order = orderResult.rows[0] as {
    id: string; user_id: string | null; guest_token_hash: string | null;
    amount_paise: number; currency: string; status: string;
  } | undefined;
  if (!order) return NextResponse.json({ error: "Payment order not found for this session." }, { status: 404 });
  if (!verifyHmacHex(`${orderId}|${paymentId}`, keySecret, signature)) {
    return NextResponse.json({ error: "Payment signature verification failed." }, { status: 400 });
  }

  try {
    const payment = await razorpayRequest<{
      id: string; order_id: string; amount: number; currency: string; status: string;
    }>(`/payments/${encodeURIComponent(paymentId)}`, "GET");
    if (payment.order_id !== orderId || Number(payment.amount) !== Number(order.amount_paise) || payment.currency !== order.currency) {
      return NextResponse.json({ error: "Payment details do not match this order." }, { status: 400 });
    }
    if (payment.status !== "captured") {
      return NextResponse.json({
        ok: true, pending: true, message: "Payment is awaiting capture. Credits will appear once Razorpay confirms it.",
      }, { status: 202 });
    }

    const client = await getPool().connect();
    let grant;
    try {
      await client.query("begin");
      grant = await fulfillCapturedPayment(client, {
        razorpayOrderId: orderId, razorpayPaymentId: paymentId,
        amountPaise: Number(payment.amount), currency: payment.currency,
      });
      await client.query("commit");
    } catch (error) {
      await client.query("rollback").catch(() => {});
      throw error;
    } finally {
      client.release();
    }
    return NextResponse.json({ ok: true, creditsAdded: grant.credits, alreadyPaid: grant.alreadyPaid });
  } catch (error) {
    console.error("Payment verification failed", error);
    return NextResponse.json({ error: "We could not confirm this payment yet. Please refresh your credit balance in a moment." }, { status: 502 });
  }
}
