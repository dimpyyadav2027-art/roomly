import { createHash } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/db";
import { getRazorpayConfig, verifyWebhookSignature, fulfillCapturedPayment } from "@/lib/razorpay";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type WebhookPayload = {
  event?: string;
  payload?: {
    payment?: { entity?: { id?: string; order_id?: string; amount?: number; currency?: string; status?: string } };
    order?: { entity?: { id?: string; amount_paid?: number; status?: string } };
  };
};

export async function POST(request: NextRequest) {
  const { webhookSecret } = getRazorpayConfig();
  if (!webhookSecret) return NextResponse.json({ error: "Webhook is not configured." }, { status: 503 });
  const rawBody = await request.text();
  const signature = request.headers.get("x-razorpay-signature") ?? "";
  if (!verifyWebhookSignature(rawBody, webhookSecret, signature)) {
    return NextResponse.json({ error: "Invalid webhook signature." }, { status: 400 });
  }

  let event: WebhookPayload;
  try { event = JSON.parse(rawBody) as WebhookPayload; } catch {
    return NextResponse.json({ error: "Invalid webhook payload." }, { status: 400 });
  }
  const eventType = typeof event.event === "string" ? event.event : "unknown";
  const payment = event.payload?.payment?.entity;
  const order = event.payload?.order?.entity;
  const eventId = request.headers.get("x-razorpay-event-id") || createHash("sha256").update(rawBody).digest("hex");

  // Only captured payments grant credits. Other signed events are acknowledged
  // and recorded so Razorpay doesn't retry harmless notifications forever.
  const isCapturedEvent = eventType === "payment.captured" || eventType === "order.paid";
  const capturedPayment = payment && payment.status === "captured" ? payment : null;

  const client = await getPool().connect();
  try {
    await client.query("begin");
    const inserted = await client.query(
      `insert into public.roomly_razorpay_webhook_events (event_id, event_type)
       values ($1, $2) on conflict (event_id) do nothing returning event_id`,
      [eventId, eventType],
    );
    if (!inserted.rowCount) {
      await client.query("commit");
      return NextResponse.json({ received: true, duplicate: true });
    }

    if (isCapturedEvent && capturedPayment?.id && capturedPayment.order_id &&
        Number.isInteger(capturedPayment.amount) && capturedPayment.currency) {
      await fulfillCapturedPayment(client, {
        razorpayOrderId: capturedPayment.order_id,
        razorpayPaymentId: capturedPayment.id,
        amountPaise: Number(capturedPayment.amount),
        currency: capturedPayment.currency,
      });
    } else if (eventType === "payment.failed") {
      // A failed attempt does not close the Razorpay order; the customer may retry.
      // The signed event is recorded, but credits are never granted for failures.
    }
    await client.query("commit");
    return NextResponse.json({ received: true });
  } catch (error) {
    await client.query("rollback").catch(() => {});
    console.error("Razorpay webhook processing failed", error);
    return NextResponse.json({ error: "Webhook processing failed; please retry." }, { status: 500 });
  } finally {
    client.release();
  }
}
