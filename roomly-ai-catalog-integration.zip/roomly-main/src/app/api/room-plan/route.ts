import { NextRequest, NextResponse } from "next/server";
import { getSupabaseAdmin, hasSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const maxDuration = 30;

type CatalogProduct = {
  id: string;
  title: string;
  description: string | null;
  category: string;
  price_inr: number;
  image_url: string;
  product_url: string;
  affiliate_url: string | null;
  brand: string | null;
  colour: string | null;
  style_tags: string[] | null;
  room_types: string[] | null;
};

const THEME_TERMS: Record<string, string[]> = {
  "Warm minimal": ["warm minimal", "minimal", "neutral", "natural", "scandinavian"],
  "Earthy retreat": ["earthy retreat", "earthy", "botanical", "natural", "rustic", "boho"],
  "Coastal calm": ["coastal calm", "coastal", "blue", "airy", "minimal"],
  "Modern Indian": ["modern indian", "indian", "handmade", "block print", "indigo", "terracotta"],
};

function fallbackRank(products: CatalogProduct[], theme: string, roomType: string, budget: number) {
  const themeTerms = (THEME_TERMS[theme] ?? [theme]).map((term) => term.toLowerCase());
  const room = roomType.toLowerCase();
  const ranked = products
    .map((product) => {
      const tags = [...(product.style_tags ?? []), ...(product.room_types ?? []), product.category, product.colour ?? ""]
        .join(" ").toLowerCase();
      const themeScore = themeTerms.reduce((score, term) => score + (tags.includes(term) ? 2 : 0), 0);
      const roomScore = (product.room_types ?? []).some((r) => room.includes(r.toLowerCase()) || r.toLowerCase().includes(room)) ? 1 : 0;
      return { product, score: themeScore + roomScore };
    })
    .filter(({ product }) => product.price_inr <= budget)
    .sort((a, b) => b.score - a.score || a.product.price_inr - b.product.price_inr);
  const chosen: CatalogProduct[] = [];
  let total = 0;
  for (const { product } of ranked) {
    if (chosen.length >= 8) break;
    if (total + product.price_inr <= budget) {
      chosen.push(product);
      total += product.price_inr;
    }
  }
  return chosen;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as {
      image?: string;
      theme?: string;
      roomType?: string;
      budget?: number;
      consent?: boolean;
    };

    if (body.consent !== true) {
      return NextResponse.json({ error: "Please confirm consent before analysing your room photo." }, { status: 400 });
    }
    if (typeof body.image !== "string" || !/^data:image\/(jpeg|jpg|png|webp);base64,/.test(body.image)) {
      return NextResponse.json({ error: "Please upload a valid room photo." }, { status: 400 });
    }
    if (body.image.length > 8 * 1024 * 1024) {
      return NextResponse.json({ error: "The room photo is too large. Please try a smaller image." }, { status: 413 });
    }
    const theme = typeof body.theme === "string" ? body.theme : "Warm minimal";
    const roomType = typeof body.roomType === "string" ? body.roomType : "Rented apartment";
    const budget = typeof body.budget === "number" && Number.isFinite(body.budget) ? Math.max(0, body.budget) : 6000;

    if (!hasSupabase()) {
      return NextResponse.json({
        products: [],
        mode: "catalog-unavailable",
        message: "The product catalog is not connected yet. Configure Supabase and import real products to enable Shop the Look.",
      });
    }

    const supabase = getSupabaseAdmin();
    const { data, error } = await supabase
      .from("roomly_products")
      .select("id,title,description,category,price_inr,image_url,product_url,affiliate_url,brand,colour,style_tags,room_types")
      .eq("active", true)
      .lte("price_inr", budget)
      .order("price_inr", { ascending: true })
      .limit(100);

    if (error) {
      console.error("Roomly product catalog query failed", error.message);
      return NextResponse.json({
        products: [],
        mode: "catalog-unavailable",
        message: "The product catalog is not ready yet. Run the catalog SQL migration in Supabase first.",
      });
    }

    const products = (data ?? []) as CatalogProduct[];
    if (!products.length) {
      return NextResponse.json({
        products: [],
        mode: "catalog-empty",
        message: "Your catalog is ready, but no active products fit this budget yet. Import real product data to show shoppable recommendations.",
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    let selected: CatalogProduct[] = [];
    let mode = "style-match";
    let summary = `Product suggestions for ${theme.toLowerCase()} within your ₹${budget.toLocaleString("en-IN")} budget.`;

    if (apiKey) {
      try {
        const match = /^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/.exec(body.image);
        if (match) {
          const mimeType = match[1] === "jpg" ? "image/jpeg" : `image/${match[1]}`;
          const catalogForModel = products.map((p) => ({
            id: p.id,
            title: p.title,
            description: p.description,
            category: p.category,
            price_inr: p.price_inr,
            brand: p.brand,
            colour: p.colour,
            style_tags: p.style_tags,
            room_types: p.room_types,
          }));
          const prompt = [
            "You are Roomly's interior design product planner.",
            "Analyse the supplied room photo and recommend only products from the catalog JSON below.",
            "Do not invent products, prices, links, dimensions, or stock claims.",
            "Respect the requested theme, room type and budget. Select up to 8 products, prefer a coherent mix of categories, and keep the total price within budget.",
            "Return JSON only with keys: productIds (array of catalog IDs), roomSummary (one short sentence).",
            `Theme: ${theme}. Room type: ${roomType}. Total budget in INR: ${budget}.`,
            `CATALOG JSON: ${JSON.stringify(catalogForModel)}`,
          ].join("\n");
          const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mimeType, data: match[2] } }] }],
                generationConfig: { responseMimeType: "application/json" },
              }),
              signal: AbortSignal.timeout(25_000),
            },
          );
          if (response.ok) {
            const result = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
            const text = result.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
            const parsed = JSON.parse(text) as { productIds?: unknown; roomSummary?: unknown };
            const ids = Array.isArray(parsed.productIds) ? parsed.productIds.filter((id): id is string => typeof id === "string") : [];
            const byId = new Map(products.map((p) => [p.id, p]));
            selected = ids.map((id) => byId.get(id)).filter((p): p is CatalogProduct => Boolean(p));
            // Enforce the budget again server-side, even if the model returns invalid picks.
            const affordable: CatalogProduct[] = [];
            let total = 0;
            for (const product of selected) {
              if (affordable.length >= 8) break;
              if (total + product.price_inr <= budget) {
                affordable.push(product);
                total += product.price_inr;
              }
            }
            selected = affordable;
            if (typeof parsed.roomSummary === "string") summary = parsed.roomSummary.slice(0, 240);
            if (selected.length) mode = "gemini-vision";
          } else {
            console.error("Gemini room planning failed", response.status, (await response.text()).slice(0, 250));
          }
        }
      } catch (error) {
        console.error("Gemini room planning unavailable; using catalog style matching", error);
      }
    }

    if (!selected.length) selected = fallbackRank(products, theme, roomType, budget);
    return NextResponse.json({
      products: selected,
      mode,
      summary,
      message: mode === "style-match"
        ? "Suggestions are matched to your style and budget. Add GEMINI_API_KEY to enable photo-aware product planning."
        : undefined,
    });
  } catch (error) {
    console.error("Roomly room plan error", error);
    return NextResponse.json({ error: "Could not build product recommendations right now." }, { status: 500 });
  }
}
