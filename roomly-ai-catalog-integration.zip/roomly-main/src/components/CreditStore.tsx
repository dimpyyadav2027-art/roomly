"use client";

import { useCallback, useEffect, useState } from "react";
import { getSupabaseBrowser } from "@/lib/supabase-browser";

type Pack = { id: "starter" | "popular" | "studio"; name: string; credits: number; price: string; featured?: boolean };
type BalanceResponse = { enabled?: boolean; balance?: number; account?: boolean; packs?: Pack[]; error?: string };
type CreateOrderResponse = { orderId?: string; amount?: number; currency?: string; keyId?: string; pack?: { name: string; credits: number }; error?: string };
type RazorpaySuccess = { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string };
type RazorpayOptions = {
  key: string; amount: number; currency: string; name: string; description: string;
  order_id: string; theme?: { color: string };
  handler: (response: RazorpaySuccess) => void | Promise<void>;
  modal?: { ondismiss?: () => void };
  prefill?: { email?: string };
};
declare global {
  interface Window {
    Razorpay?: new (options: RazorpayOptions) => { open: () => void };
  }
}

export default function CreditStore({ sessionEmail, notify }: { sessionEmail: string | null; notify: (message: string) => void }) {
  const [open, setOpen] = useState(false);
  const [loadingPack, setLoadingPack] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);
  const [enabled, setEnabled] = useState(false);
  const [packs, setPacks] = useState<Pack[]>([
    { id: "starter", name: "Starter", credits: 3, price: "₹49" },
    { id: "popular", name: "Popular", credits: 8, price: "₹99", featured: true },
    { id: "studio", name: "Studio", credits: 20, price: "₹199" },
  ]);
  const [error, setError] = useState<string | null>(null);

  const getHeaders = useCallback(async () => {
    const session = await getSupabaseBrowser()?.auth.getSession();
    const token = session?.data.session?.access_token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  }, []);

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/credits", { headers: await getHeaders(), cache: "no-store" });
      const data = (await response.json()) as BalanceResponse;
      if (response.ok) {
        setBalance(Number(data.balance ?? 0));
        setEnabled(data.enabled === true);
        if (Array.isArray(data.packs)) setPacks(data.packs);
      }
    } catch { /* Balance remains last known value. */ }
  }, [getHeaders]);

  useEffect(() => { void refresh(); }, [refresh, sessionEmail]);

  useEffect(() => {
    if (!sessionEmail) return;
    void (async () => {
      try {
        const response = await fetch("/api/credits/claim", { method: "POST", headers: await getHeaders() });
        if (response.ok) {
          const data = await response.json() as { transferred?: number };
          if ((data.transferred ?? 0) > 0) {
            notify(`Moved ${data.transferred} guest credits to your account.`);
            await refresh();
          }
        }
      } catch { /* Claim can be retried on the next sign-in. */ }
    })();
  }, [sessionEmail, getHeaders, notify, refresh]);

  const loadCheckout = async () => {
    if (window.Razorpay) return true;
    return new Promise<boolean>((resolve) => {
      const existing = document.querySelector<HTMLScriptElement>('script[data-roomly-razorpay="true"]');
      if (existing) {
        existing.addEventListener("load", () => resolve(Boolean(window.Razorpay)), { once: true });
        existing.addEventListener("error", () => resolve(false), { once: true });
        return;
      }
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.async = true;
      script.dataset.roomlyRazorpay = "true";
      script.onload = () => resolve(Boolean(window.Razorpay));
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const buy = async (pack: Pack) => {
    setLoadingPack(pack.id);
    setError(null);
    try {
      const headers = await getHeaders();
      const response = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...headers },
        body: JSON.stringify({ packId: pack.id }),
      });
      const order = (await response.json()) as CreateOrderResponse;
      if (!response.ok || !order.orderId || !order.keyId || !order.amount || !order.currency) {
        throw new Error(order.error || "Could not start checkout.");
      }
      if (!(await loadCheckout()) || !window.Razorpay) throw new Error("Razorpay Checkout could not load. Check your connection and try again.");

      const checkout = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        name: "Roomly",
        description: `${order.pack?.credits ?? pack.credits} AI room restyle credits`,
        order_id: order.orderId,
        theme: { color: "#9b563c" },
        prefill: sessionEmail ? { email: sessionEmail } : undefined,
        handler: async (payment) => {
          try {
            const verifyResponse = await fetch("/api/payments/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json", ...await getHeaders() },
              body: JSON.stringify(payment),
            });
            const verified = await verifyResponse.json() as { ok?: boolean; pending?: boolean; error?: string };
            if (!verifyResponse.ok) throw new Error(verified.error || "Payment confirmation is pending.");
            if (verified.pending) {
              notify("Payment received by Razorpay; credits will appear after capture confirmation.");
            } else {
              notify("Payment verified. Your credits are ready.");
            }
            await refresh();
          } catch (verifyError) {
            setError(verifyError instanceof Error ? verifyError.message : "Payment confirmation is pending. Refresh your balance shortly.");
          } finally {
            setLoadingPack(null);
          }
        },
        modal: { ondismiss: () => setLoadingPack(null) },
      });
      checkout.open();
    } catch (buyError) {
      setError(buyError instanceof Error ? buyError.message : "Checkout could not start.");
      setLoadingPack(null);
    }
  };

  return (
    <>
      <button className="text-button" onClick={() => { setOpen(true); void refresh(); }} aria-label="Open AI credit balance">
        Credits · {balance}
      </button>
      {open && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Buy AI credits" onClick={(event) => { if (event.target === event.currentTarget) setOpen(false); }}>
          <div className="api-modal roomly-credit-modal">
            <button className="modal-close" onClick={() => setOpen(false)} aria-label="Close credit store">Close</button>
            <span className="section-kicker">ROOMLY AI CREDITS</span>
            <h2>Make your next room idea real.</h2>
            <p>Balance: <strong>{balance} {balance === 1 ? "credit" : "credits"}</strong>{sessionEmail ? ` · ${sessionEmail}` : " · Guest checkout available"}</p>
            {!enabled && <p className="ai-error">Checkout is not enabled yet. The site owner needs to configure Razorpay and run the Supabase credit migration.</p>}
            <div className="roomly-credit-packs">
              {packs.map((pack) => (
                <article className={`roomly-credit-pack ${pack.featured ? "featured" : ""}`} key={pack.id}>
                  {pack.featured && <span className="roomly-credit-badge">Popular</span>}
                  <h3>{pack.name}</h3>
                  <p className="roomly-credit-count">{pack.credits} AI credits</p>
                  <p className="roomly-credit-price">{pack.price}</p>
                  <button className="primary-button" disabled={!enabled || loadingPack !== null} onClick={() => void buy(pack)}>
                    {loadingPack === pack.id ? "Opening checkout…" : "Buy credits"}
                  </button>
                </article>
              ))}
            </div>
            <p className="generation-note">One credit is used for each successful AI room restyle. If generation fails, Roomly attempts to return the credit. Payments are processed securely by Razorpay.</p>
            {error && <p className="ai-error">{error}</p>}
            <button className="email-login" onClick={() => { void refresh(); notify("Credit balance refreshed."); }}>Refresh balance</button>
          </div>
        </div>
      )}
    </>
  );
}
