"use client";

import { useState } from "react";

type CatalogProduct = {
  id: string;
  title: string;
  description: string | null;
  category: string;
  price_inr: number;
  image_url: string;
  product_url: string;
  affiliate_url: string | null;
  brand: string | null;
  colour: string | null;
  style_tags: string[] | null;
};

type Props = {
  image: string | null;
  theme: string;
  roomType: string;
  budget: number;
};

function inr(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}

export default function ShopTheLook({ image, theme, roomType, budget }: Props) {
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [message, setMessage] = useState("");
  const [summary, setSummary] = useState("");
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [mode, setMode] = useState("");

  const findProducts = async () => {
    if (!image || !consent || busy) return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const response = await fetch("/api/room-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image, theme, roomType, budget, consent: true }),
      });
      const result = await response.json() as {
        products?: CatalogProduct[];
        mode?: string;
        summary?: string;
        message?: string;
        error?: string;
      };
      if (!response.ok) throw new Error(result.error || "Could not find products right now.");
      setProducts(Array.isArray(result.products) ? result.products : []);
      setSummary(typeof result.summary === "string" ? result.summary : "");
      setMessage(typeof result.message === "string" ? result.message : "");
      setMode(result.mode ?? "");
      setLoaded(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not find products right now.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section aria-labelledby="roomly-shop-look-title" style={{ marginTop: 24, padding: 20, border: "1px solid #e8e2d8", borderRadius: 18, background: "#fffdf9", color: "#292820" }}>
      <p style={{ margin: "0 0 6px", fontSize: 11, letterSpacing: ".14em", fontWeight: 700, color: "#85745f" }}>ROOMLY CATALOG</p>
      <h3 id="roomly-shop-look-title" style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 650 }}>Shop the look</h3>
      <p style={{ margin: "0 0 14px", lineHeight: 1.55, color: "#625e54", fontSize: 14 }}>
        Find real products from Roomly's catalog that suit your room, chosen style and budget. AI renders are visual concepts; product cards and retailer listings are the source of truth.
      </p>
      <label style={{ display: "flex", alignItems: "flex-start", gap: 10, margin: "14px 0", fontSize: 13, lineHeight: 1.5, color: "#625e54" }}>
        <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} style={{ marginTop: 3 }} />
        <span>I agree to send this room photo to Google Gemini for room-aware product recommendations. Google's service terms and data practices apply to that processing. I can leave this unchecked and use the existing Roomly tools.</span>
      </label>
      <button type="button" onClick={findProducts} disabled={!image || !consent || busy} style={{ border: 0, borderRadius: 999, padding: "12px 18px", background: !image || !consent || busy ? "#d8d4cb" : "#33392c", color: "#fff", fontWeight: 650, cursor: !image || !consent || busy ? "not-allowed" : "pointer" }}>
        {busy ? "Finding matching products…" : loaded ? "Refresh recommendations" : "Find products for my room"}
      </button>
      {error && <p role="alert" style={{ color: "#9d3428", fontSize: 14 }}>{error}</p>}
      {message && <p style={{ margin: "12px 0 0", color: "#6a6256", fontSize: 13 }}>{message}</p>}
      {summary && <p style={{ margin: "14px 0", fontSize: 14, lineHeight: 1.5 }}>{summary}</p>}
      {loaded && products.length === 0 && !message && <p style={{ marginTop: 14, color: "#6a6256" }}>No matching products were found. Add active items to the Roomly catalog and try again.</p>}
      {products.length > 0 && (
        <>
          <p style={{ margin: "16px 0 10px", color: "#6a6256", fontSize: 12 }}>
            {mode === "gemini-vision" ? "Photo-aware AI suggestions" : "Style and budget matches"} · Prices and availability may change.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
            {products.map((product) => (
              <article key={product.id} style={{ overflow: "hidden", border: "1px solid #e8e2d8", borderRadius: 14, background: "#fff" }}>
                <a href={product.affiliate_url || product.product_url} target="_blank" rel="noopener noreferrer" style={{ color: "inherit", textDecoration: "none" }}>
                  <div style={{ aspectRatio: "4 / 3", background: "#f0ece4" }}>
                    {/* Catalog image URLs are supplied by the catalog owner. */}
                    <img src={product.image_url} alt={product.title} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                  </div>
                  <div style={{ padding: 12 }}>
                    <p style={{ margin: "0 0 4px", fontSize: 11, textTransform: "uppercase", letterSpacing: ".08em", color: "#85745f" }}>{product.brand || product.category}</p>
                    <h4 style={{ margin: "0 0 6px", fontSize: 15, lineHeight: 1.35 }}>{product.title}</h4>
                    <p style={{ margin: "0 0 10px", fontWeight: 700 }}>{inr(product.price_inr)}</p>
                    <span style={{ fontSize: 13, textDecoration: "underline" }}>View product ↗</span>
                  </div>
                </a>
              </article>
            ))}
          </div>
          <p style={{ margin: "14px 0 0", fontSize: 12, color: "#777065", lineHeight: 1.5 }}>
            Visualizations may show a similar-looking item rather than the exact product. Check the retailer listing for the actual product details.
          </p>
        </>
      )}
    </section>
  );
}
