import { createHmac, randomBytes, randomUUID, timingSafeEqual, createHash } from "node:crypto";
import type { PoolClient } from "pg";
import { getPool } from "@/db";
import { getSessionUser } from "@/lib/auth";

export const CREDIT_PACKS = {
  starter: { id: "starter", name: "Starter", credits: 3, amountPaise: 4900, displayPrice: "₹49" },
  popular: { id: "popular", name: "Popular", credits: 8, amountPaise: 9900, displayPrice: "₹99" },
  studio: { id: "studio", name: "Studio", credits: 20, amountPaise: 19900, displayPrice: "₹199" },
} as const;

export type CreditPackId = keyof typeof CREDIT_PACKS;
export type PaymentOwner = { userId: string | null; guestTokenHash: string | null };

export function getRazorpayConfig() {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
  return { keyId, keySecret, webhookSecret, enabled: Boolean(keyId && keySecret) };
}

export function getGuestToken(request: Request): string | null {
  const cookie = request.headers.get("cookie") ?? "";
  const match = cookie.match(/(?:^|;\s*)roomly_guest=([^;]+)/);
  if (!match) return null;
  try {
    const value = decodeURIComponent(match[1]);
    return /^[A-Za-z0-9_-]{40,80}$/.test(value) ? value : null;
  } catch {
    return null;
  }
}

export function hashGuestToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function resolvePaymentOwner(request: Request): Promise<{
  owner: PaymentOwner;
  newGuestToken?: string;
}> {
  const user = await getSessionUser(request);
  if (user) return { owner: { userId: user.id, guestTokenHash: null } };

  const existing = getGuestToken(request);
  if (existing) return { owner: { userId: null, guestTokenHash: hashGuestToken(existing) } };

  const token = randomBytes(32).toString("base64url");
  return { owner: { userId: null, guestTokenHash: hashGuestToken(token) }, newGuestToken: token };
}

export function attachGuestCookie(response: Response, token?: string, secure = true) {
  if (token) {
    response.headers.append(
      "Set-Cookie",
      `roomly_guest=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${secure ? "; Secure" : ""}`,
    );
  }
  return response;
}

export function verifyHmacHex(message: string, secret: string, supplied: string): boolean {
  if (!/^[a-f0-9]{64}$/i.test(supplied)) return false;
  const expected = createHmac("sha256", secret).update(message).digest();
  const actual = Buffer.from(supplied, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export function verifyWebhookSignature(rawBody: string, secret: string, supplied: string): boolean {
  if (!/^[a-f0-9]{64}$/i.test(supplied)) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest();
  const actual = Buffer.from(supplied, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export async function razorpayRequest<T>(path: string, method: "GET" | "POST", body?: unknown): Promise<T> {
  const { keyId, keySecret } = getRazorpayConfig();
  if (!keyId || !keySecret) throw new Error("Razorpay is not configured");
  const response = await fetch(`https://api.razorpay.com/v1${path}`, {
    method,
    headers: {
      Authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
      "Content-Type": "application/json",
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    cache: "no-store",
    signal: AbortSignal.timeout(20_000),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("Razorpay API error", response.status);
    throw new Error("Payment provider request failed");
  }
  return data as T;
}

export async function fulfillCapturedPayment(
  client: PoolClient,
  input: { razorpayOrderId: string; razorpayPaymentId: string; amountPaise: number; currency: string },
) {
  const result = await client.query(
    `select id, user_id, guest_token_hash, amount_paise, credits, currency, status, razorpay_payment_id
       from public.roomly_payment_orders
      where razorpay_order_id = $1
      for update`,
    [input.razorpayOrderId],
  );
  const order = result.rows[0] as {
    id: string; user_id: string | null; guest_token_hash: string | null;
    amount_paise: number; credits: number; currency: string; status: string; razorpay_payment_id: string | null;
  } | undefined;
  if (!order) throw new Error("Unknown payment order");
  if (Number(order.amount_paise) !== input.amountPaise || order.currency !== input.currency || input.currency !== "INR") {
    throw new Error("Payment amount or currency mismatch");
  }
  if (order.status === "paid") {
    if (order.razorpay_payment_id && order.razorpay_payment_id !== input.razorpayPaymentId) {
      throw new Error("Order already fulfilled by a different payment");
    }
    return { alreadyPaid: true, credits: order.credits };
  }
  if (order.status === "failed" || order.status === "cancelled") {
    throw new Error("Payment order is no longer payable");
  }

  const wallet = order.user_id
    ? await (async () => {
        await client.query(
          `insert into public.roomly_credit_wallets (user_id, balance) values ($1, 0)
           on conflict (user_id) where user_id is not null do nothing`,
          [order.user_id],
        );
        return client.query(
          `select id, balance from public.roomly_credit_wallets where user_id = $1 for update`,
          [order.user_id],
        );
      })()
    : await (async () => {
        if (!order.guest_token_hash) throw new Error("Payment order has no owner");
        await client.query(
          `insert into public.roomly_credit_wallets (guest_token_hash, balance) values ($1, 0)
           on conflict (guest_token_hash) where guest_token_hash is not null do nothing`,
          [order.guest_token_hash],
        );
        return client.query(
          `select id, balance from public.roomly_credit_wallets where guest_token_hash = $1 for update`,
          [order.guest_token_hash],
        );
      })();

  const walletRow = wallet.rows[0] as { id: string; balance: number } | undefined;
  if (!walletRow) throw new Error("Could not create credit wallet");

  await client.query(
    `update public.roomly_credit_wallets set balance = balance + $1, updated_at = now() where id = $2`,
    [order.credits, walletRow.id],
  );
  await client.query(
    `insert into public.roomly_credit_ledger (wallet_id, kind, credits, payment_order_id, note)
     values ($1, 'purchase', $2, $3, $4)
     on conflict (payment_order_id) where payment_order_id is not null do nothing`,
    [walletRow.id, order.credits, order.id, `Razorpay payment ${input.razorpayPaymentId}`],
  );
  await client.query(
    `update public.roomly_payment_orders
        set status = 'paid', razorpay_payment_id = $1, paid_at = now(), updated_at = now()
      where id = $2`,
    [input.razorpayPaymentId, order.id],
  );
  return { alreadyPaid: false, credits: order.credits };
}

export async function spendAiCredit(request: Request): Promise<
  | { ok: true; spendId: string; owner: PaymentOwner; remaining: number }
  | { ok: false; status: number; error: string }
> {
  const { userId, guestTokenHash } = (await resolvePaymentOwner(request)).owner;
  const client = await getPool().connect();
  const spendId = randomUUID();
  try {
    await client.query("begin");
    const walletResult = userId
      ? await client.query(`select id, balance from public.roomly_credit_wallets where user_id = $1 for update`, [userId])
      : guestTokenHash
        ? await client.query(`select id, balance from public.roomly_credit_wallets where guest_token_hash = $1 for update`, [guestTokenHash])
        : { rows: [] };
    const wallet = walletResult.rows[0] as { id: string; balance: number } | undefined;
    if (!wallet || Number(wallet.balance) < 1) {
      await client.query("rollback");
      return { ok: false, status: 402, error: "You need an AI credit to create a restyle. Choose a credit pack to continue." };
    }
    await client.query(`update public.roomly_credit_wallets set balance = balance - 1, updated_at = now() where id = $1`, [wallet.id]);
    await client.query(
      `insert into public.roomly_credit_ledger (wallet_id, kind, credits, request_id, note)
       values ($1, 'ai_spend', -1, $2, 'AI room restyle')`,
      [wallet.id, spendId],
    );
    await client.query("commit");
    return { ok: true, spendId, owner: { userId, guestTokenHash }, remaining: Number(wallet.balance) - 1 };
  } catch (error) {
    await client.query("rollback").catch(() => {});
    console.error("AI credit reservation failed", error);
    return { ok: false, status: 503, error: "Credits are unavailable right now. Please try again later." };
  } finally {
    client.release();
  }
}

export async function refundAiCredit(spendId: string): Promise<void> {
  const client = await getPool().connect();
  try {
    await client.query("begin");
    const spent = await client.query(
      `select wallet_id, credits from public.roomly_credit_ledger
        where request_id = $1 and kind = 'ai_spend' for update`,
      [spendId],
    );
    if (!spent.rows[0]) {
      await client.query("rollback");
      return;
    }
    const existingRefund = await client.query(
      `select id from public.roomly_credit_ledger where related_request_id = $1 and kind = 'ai_refund'`,
      [spendId],
    );
    if (existingRefund.rows[0]) {
      await client.query("rollback");
      return;
    }
    const row = spent.rows[0] as { wallet_id: string; credits: number };
    await client.query(
      `update public.roomly_credit_wallets set balance = balance + 1, updated_at = now() where id = $1`,
      [row.wallet_id],
    );
    await client.query(
      `insert into public.roomly_credit_ledger (wallet_id, kind, credits, related_request_id, note)
       values ($1, 'ai_refund', 1, $2, 'Refund for unsuccessful AI room restyle')`,
      [row.wallet_id, spendId],
    );
    await client.query("commit");
  } catch (error) {
    await client.query("rollback").catch(() => {});
    console.error("AI credit refund failed", error);
  } finally {
    client.release();
  }
}

export async function getOwnerWallet(request: Request) {
  const user = await getSessionUser(request);
  const guest = user ? null : getGuestToken(request);
  const owner: PaymentOwner = user
    ? { userId: user.id, guestTokenHash: null }
    : { userId: null, guestTokenHash: guest ? hashGuestToken(guest) : null };
  if (!owner.userId && !owner.guestTokenHash) return { owner, balance: 0 };
  const result = owner.userId
    ? await getPool().query(`select balance from public.roomly_credit_wallets where user_id = $1`, [owner.userId])
    : await getPool().query(`select balance from public.roomly_credit_wallets where guest_token_hash = $1`, [owner.guestTokenHash]);
  return { owner, balance: Number(result.rows[0]?.balance ?? 0) };
}
