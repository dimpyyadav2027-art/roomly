-- Roomly Razorpay credit packs (INR). Run once in Supabase SQL Editor.
-- Tables are server-only: RLS is enabled and no browser policies are added.
-- The app accesses them with DATABASE_URL from server-side Next.js routes.

create table if not exists public.roomly_payment_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  guest_token_hash text,
  pack_id text not null check (pack_id in ('starter', 'popular', 'studio')),
  credits integer not null check (credits > 0),
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR' check (currency = 'INR'),
  status text not null default 'creating'
    check (status in ('creating', 'created', 'paid', 'failed', 'cancelled')),
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((user_id is not null) <> (guest_token_hash is not null))
);

create index if not exists roomly_payment_orders_user_created
  on public.roomly_payment_orders (user_id, created_at desc) where user_id is not null;
create index if not exists roomly_payment_orders_guest_created
  on public.roomly_payment_orders (guest_token_hash, created_at desc) where guest_token_hash is not null;

create table if not exists public.roomly_credit_wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  guest_token_hash text,
  balance integer not null default 0 check (balance >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((user_id is not null) <> (guest_token_hash is not null))
);

create unique index if not exists roomly_credit_wallets_user_unique
  on public.roomly_credit_wallets (user_id) where user_id is not null;
create unique index if not exists roomly_credit_wallets_guest_unique
  on public.roomly_credit_wallets (guest_token_hash) where guest_token_hash is not null;

create table if not exists public.roomly_credit_ledger (
  id uuid primary key default gen_random_uuid(),
  wallet_id uuid not null references public.roomly_credit_wallets(id),
  kind text not null check (kind in ('purchase', 'ai_spend', 'ai_refund', 'transfer_in', 'transfer_out')),
  credits integer not null check (credits <> 0),
  payment_order_id uuid references public.roomly_payment_orders(id),
  request_id uuid,
  related_request_id uuid,
  transfer_id uuid,
  note text,
  created_at timestamptz not null default now()
);
create unique index if not exists roomly_credit_ledger_order_unique
  on public.roomly_credit_ledger (payment_order_id) where payment_order_id is not null;
create unique index if not exists roomly_credit_ledger_request_unique
  on public.roomly_credit_ledger (request_id) where request_id is not null;
create unique index if not exists roomly_credit_ledger_refund_unique
  on public.roomly_credit_ledger (related_request_id) where related_request_id is not null;
create index if not exists roomly_credit_ledger_wallet_created
  on public.roomly_credit_ledger (wallet_id, created_at desc);

create table if not exists public.roomly_razorpay_webhook_events (
  event_id text primary key,
  event_type text not null,
  received_at timestamptz not null default now()
);

alter table public.roomly_payment_orders enable row level security;
alter table public.roomly_credit_wallets enable row level security;
alter table public.roomly_credit_ledger enable row level security;
alter table public.roomly_razorpay_webhook_events enable row level security;

-- Intentionally no client policies: all reads/writes go through server routes.
