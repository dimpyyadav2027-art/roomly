-- Roomly's own product catalog for photo-aware "Shop the look" recommendations.
-- Import only products you have permission to promote, with accurate prices and links.
create extension if not exists pgcrypto;

create table if not exists public.roomly_products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null,
  price_inr integer not null check (price_inr >= 0),
  image_url text not null,
  product_url text not null,
  brand text,
  colour text,
  style_tags text[] not null default '{}',
  room_types text[] not null default '{}',
  dimensions jsonb,
  affiliate_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint roomly_products_image_https check (image_url ~ '^https://'),
  constraint roomly_products_url_https check (product_url ~ '^https://'),
  constraint roomly_products_affiliate_https check (affiliate_url is null or affiliate_url ~ '^https://')
);

create index if not exists roomly_products_active_price_idx
  on public.roomly_products (active, price_inr);
create index if not exists roomly_products_style_tags_idx
  on public.roomly_products using gin (style_tags);
create index if not exists roomly_products_room_types_idx
  on public.roomly_products using gin (room_types);

alter table public.roomly_products enable row level security;

-- Public visitors may read active catalog items only. Writes remain server/admin-only.
drop policy if exists "Public can read active Roomly products" on public.roomly_products;
create policy "Public can read active Roomly products"
  on public.roomly_products
  for select
  to anon, authenticated
  using (active = true);

-- No INSERT/UPDATE/DELETE policies are created for browser users.
